"""
═══════════════════════════════════════════════════════════════
ESTRATEGIA: POSICIONAL
Horizonte: 6–18 meses · Timeframe diario/semanal
═══════════════════════════════════════════════════════════════

Busca valores en tendencias primarias alcistas de largo plazo
con fundamentos sólidos. Pocas operaciones, alta convicción.

Filosofía: "Comprar negocios sólidos en tendencia y esperar"

Criterios:
  1. Tendencia primaria alcista    (precio > MM200 con margen)
  2. MM200 pendiente positiva      (al menos 3 meses de subida)
  3. MM50 por encima de MM200      (golden cross activo o reciente)
  4. RSI saludable                 (45 – 70, sin sobrecompra extrema)
  5. Fuerza relativa vs IBEX       (el valor bate al índice en 6 meses)
  6. Volumen institucional         (media 50d creciente)
  7. Precio en zona de acumulación (retroceso 5–20% desde máximo 52s)
  8. Volatilidad controlada        (ATR% < 3% del precio)
"""

import pandas as pd
import numpy as np
import logging
from datetime import datetime

from estrategias.base import EstrategiaBase
from core.indicadores import calcular_rsi, calcular_atr, calcular_macd
from core.data_provider import get_df_ibex
from core.riesgo import calcular_rr, calcular_objetivo
from core.utilidades import respuesta_invalida, respuesta_valida, f

logger = logging.getLogger(__name__)

TIPO = "POSICIONAL"


class Posicional(EstrategiaBase):

    nombre        = "Posicional"
    periodo_datos = "2y"
    min_velas     = 250       # ~1 año completo para MM200 + comparativa 52 semanas

    # ── Implementación obligatoria ─────────────────────────

    def _evaluar_df(self, df: pd.DataFrame, ticker: str) -> dict:
        motivos = []

        # ── Indicadores base ──────────────────────────────
        df = df.copy()
        df["MM50"]  = df["Close"].rolling(50).mean()
        df["MM200"] = df["Close"].rolling(200).mean()
        df["ATR"]   = calcular_atr(df, 14)
        df["RSI"]   = calcular_rsi(df["Close"], 14)

        precio_actual = f(df["Close"].iloc[-1])
        rsi_val       = f(df["RSI"].iloc[-1])
        atr_val       = f(df["ATR"].iloc[-1])
        mm50_val      = f(df["MM50"].iloc[-1])
        mm200_val     = f(df["MM200"].iloc[-1])

        variacion_1d  = self._variacion_1d(df)

        # ══════════════════════════════════════════════════
        # 1️⃣  TENDENCIA PRIMARIA ALCISTA  (precio > MM200 × 1.02)
        #     Exigimos un 2% de margen — no vale estar justo en la MM
        # ══════════════════════════════════════════════════
        dist_mm200_pct = ((precio_actual - mm200_val) / mm200_val) * 100
        tendencia_ok   = dist_mm200_pct >= 2.0

        motivos.append({
            "ok":    tendencia_ok,
            "texto": f"Precio sobre MM200 ({dist_mm200_pct:+.1f}%, mínimo +2%)"
        })

        # ══════════════════════════════════════════════════
        # 2️⃣  MM200 PENDIENTE POSITIVA (últimos 60 días ~3 meses)
        # ══════════════════════════════════════════════════
        mm200_series   = df["MM200"].dropna()
        mm200_60d_prev = f(mm200_series.iloc[-61]) if len(mm200_series) > 61 else mm200_val
        pendiente_mm200 = ((mm200_val - mm200_60d_prev) / mm200_60d_prev) * 100
        pendiente_ok    = pendiente_mm200 > 0

        motivos.append({
            "ok":    pendiente_ok,
            "texto": f"MM200 alcista últimos 60d ({pendiente_mm200:+.2f}%)"
        })

        # ══════════════════════════════════════════════════
        # 3️⃣  MM50 > MM200  (golden cross activo o reciente)
        # ══════════════════════════════════════════════════
        golden_cross_ok = mm50_val > mm200_val

        motivos.append({
            "ok":    golden_cross_ok,
            "texto": f"Golden cross: MM50 > MM200 ({mm50_val:.2f} > {mm200_val:.2f})"
        })

        # ══════════════════════════════════════════════════
        # 4️⃣  RSI SALUDABLE  (45 – 70)
        #     Rango más amplio que swing — posicional aguanta más tiempo
        # ══════════════════════════════════════════════════
        rsi_ok = 45 <= rsi_val <= 70

        motivos.append({
            "ok":    rsi_ok,
            "texto": f"RSI saludable ({rsi_val:.1f}, zona 45–70)"
        })

        # ══════════════════════════════════════════════════
        # 5️⃣  FUERZA RELATIVA VS IBEX  (6 meses)
        # ══════════════════════════════════════════════════
        fuerza_ok, fuerza_pct = _calcular_fuerza_relativa(df, ticker)

        motivos.append({
            "ok":    fuerza_ok,
            "texto": f"Fuerza relativa vs IBEX ({fuerza_pct:+.1f}% en 6 meses)"
        })

        # ══════════════════════════════════════════════════
        # 6️⃣  VOLUMEN INSTITUCIONAL  (media 50d creciente)
        # ══════════════════════════════════════════════════
        vol = df["Volume"].astype(float)
        media_vol50  = float(vol.tail(50).mean())
        media_vol100 = float(vol.tail(100).mean())
        volumen_ok   = media_vol50 > media_vol100 * 0.90  # margen 10%

        motivos.append({
            "ok":    volumen_ok,
            "texto": f"Volumen institucional creciente "
                     f"(media50={int(media_vol50):,} vs media100={int(media_vol100):,})"
        })

        # ══════════════════════════════════════════════════
        # 7️⃣  ZONA DE ACUMULACIÓN  (retroceso 5–20% desde máximo 52 semanas)
        # ══════════════════════════════════════════════════
        maximo_52s     = f(df["High"].tail(252).max())
        retroceso_52s  = ((maximo_52s - precio_actual) / maximo_52s) * 100
        acumulacion_ok = 5.0 <= retroceso_52s <= 20.0

        motivos.append({
            "ok":    acumulacion_ok,
            "texto": f"Zona acumulación: {retroceso_52s:.1f}% bajo máximo 52s "
                     f"(rango 5–20%)"
        })

        # ══════════════════════════════════════════════════
        # 8️⃣  VOLATILIDAD CONTROLADA  (ATR% < 3%)
        # ══════════════════════════════════════════════════
        atr_pct      = (atr_val / precio_actual) * 100 if precio_actual > 0 else 99
        volatilidad_ok = atr_pct < 3.0

        motivos.append({
            "ok":    volatilidad_ok,
            "texto": f"Volatilidad controlada (ATR {atr_pct:.2f}% del precio, máx 3%)"
        })

        # ══════════════════════════════════════════════════
        # VEREDICTO FINAL
        # Posicional: toleramos 1 criterio fallido (excepto 1, 2 y 3 que son obligatorios)
        # ══════════════════════════════════════════════════
        criterios_obligatorios = motivos[:3]   # tendencia, pendiente MM200, golden cross
        criterios_opcionales   = motivos[3:]   # resto

        obligatorios_ok = all(m["ok"] for m in criterios_obligatorios)
        opcionales_ok   = sum(m["ok"] for m in criterios_opcionales) >= len(criterios_opcionales) - 1

        valido = obligatorios_ok and opcionales_ok

        if not valido:
            return respuesta_invalida(
                ticker, TIPO,
                "Criterios posicionales no cumplidos",
                motivos, variacion_1d, precio_actual
            )

        # ══════════════════════════════════════════════════
        # PLAN DE TRADING
        # ══════════════════════════════════════════════════
        # Stop posicional: bajo MM200 con margen del 3%
        # Más amplio que swing/medio para aguantar volatilidad
        stop    = round(mm200_val * 0.97, 2)
        entrada = precio_actual

        riesgo_unitario = entrada - stop
        riesgo_pct_op   = (riesgo_unitario / entrada) * 100 if entrada > 0 else 0

        setup_score = sum(m["ok"] for m in motivos)

        objetivo = calcular_objetivo(
            entrada=entrada,
            stop=stop,
            atr=atr_val,
            setup_score=setup_score,
            rr_minimo=3.0,      # posicional exige RR mínimo de 3
        )
        rr = calcular_rr(entrada, stop, objetivo)

        return respuesta_valida(
            ticker=ticker,
            tipo=TIPO,
            entrada=entrada,
            stop=stop,
            objetivo=objetivo,
            rr=rr,
            setup_score=setup_score,
            motivos=motivos,
            variacion_1d=variacion_1d,
            precio_actual=precio_actual,
            # Campos extra específicos de POSICIONAL
            riesgo_pct=round(riesgo_pct_op, 2),
            beneficio_pct=round(((objetivo - entrada) / entrada) * 100, 2) if objetivo else 0,
            dist_mm200_pct=round(dist_mm200_pct, 2),
            pendiente_mm200=round(pendiente_mm200, 2),
            retroceso_52s=round(retroceso_52s, 2),
            maximo_52s=round(maximo_52s, 2),
            fuerza_relativa=round(fuerza_pct, 2),
            atr_pct=round(atr_pct, 2),
            rsi=round(rsi_val, 1),
            atr=round(atr_val, 2),
            mm50=round(mm50_val, 2),
            mm200=round(mm200_val, 2),
            fecha=datetime.now().strftime("%Y-%m-%d %H:%M"),
        )


# ─────────────────────────────────────────────────────────────
# FUNCIONES AUXILIARES PRIVADAS
# ─────────────────────────────────────────────────────────────

def _calcular_fuerza_relativa(df: pd.DataFrame, ticker: str) -> tuple:
    """
    Compara la rentabilidad del valor vs IBEX en los últimos 6 meses (~126 sesiones).

    Returns:
        (bool fuerza_ok, float diferencia_pct)
        fuerza_ok = True si el valor supera al IBEX
    """
    try:
        from core.data_provider import get_df_ibex

        df_ibex = get_df_ibex(cache=None, periodo="1y")
        if df_ibex is None or len(df_ibex) < 126:
            # Sin datos del IBEX: criterio neutral (no penaliza)
            return True, 0.0

        ventana = 126  # ~6 meses

        # Rentabilidad del valor
        precio_hoy   = f(df["Close"].iloc[-1])
        precio_6m    = f(df["Close"].iloc[-ventana]) if len(df) >= ventana else f(df["Close"].iloc[0])
        rent_valor   = ((precio_hoy - precio_6m) / precio_6m) * 100

        # Rentabilidad del IBEX
        ibex_hoy  = f(df_ibex["Close"].iloc[-1])
        ibex_6m   = f(df_ibex["Close"].iloc[-ventana]) if len(df_ibex) >= ventana else f(df_ibex["Close"].iloc[0])
        rent_ibex = ((ibex_hoy - ibex_6m) / ibex_6m) * 100

        diferencia = rent_valor - rent_ibex
        fuerza_ok  = diferencia >= 0  # el valor bate o iguala al IBEX

        return fuerza_ok, diferencia

    except Exception as e:
        logger.warning(f"⚠️ Fuerza relativa no calculable para {ticker}: {e}")
        return True, 0.0   # criterio neutral si falla


# ══════════════════════════════════════════════════════════════
# FUNCIONES DE ANÁLISIS TÉCNICO POSICIONAL
# (requeridas por sistema_trading_posicional.py)
# ══════════════════════════════════════════════════════════════

import numpy as np


def detectar_tendencia_largo_plazo(precios, df=None):
    """
    Analiza tendencia de largo plazo con MM50 y MM200 semanales.

    Returns dict:
        tendencia:             "ALCISTA" | "BAJISTA" | "LATERAL"
        mm50, mm200:           valores actuales
        distancia_mm50_pct:    % precio sobre/bajo MM50
        pendiente_mm50:        diferencia MM50 hoy vs 4 semanas atrás
        cumple_criterios:      bool — todas las condiciones OK
        condiciones:           dict detalle
    """
    if hasattr(precios, 'tolist'): precios = precios.tolist()
    n = len(precios)
    precio = precios[-1]

    # MM50 y MM200
    mm50  = sum(precios[-50:]) / 50  if n >= 50  else None
    mm200 = sum(precios[-200:]) / 200 if n >= 200 else None

    # Pendiente MM50 (comparar vs 4 semanas atrás)
    if n >= 54:
        mm50_ant = sum(precios[-54:-4]) / 50
        pendiente_mm50 = mm50 - mm50_ant
    else:
        pendiente_mm50 = 0.0

    distancia_mm50_pct = ((precio - mm50) / mm50 * 100) if mm50 else None

    # Condiciones
    cond_sobre_mm50       = bool(mm50  and precio > mm50)
    cond_sobre_mm200      = bool(mm200 and precio > mm200)
    cond_mm50_sobre_mm200 = bool(mm50 and mm200 and mm50 > mm200)
    cond_pendiente        = pendiente_mm50 > 0
    cond_distancia        = bool(distancia_mm50_pct and distancia_mm50_pct >= 1.0)

    condiciones = {
        "sobre_mm50":       cond_sobre_mm50,
        "sobre_mm200":      cond_sobre_mm200,
        "mm50_sobre_mm200": cond_mm50_sobre_mm200,
        "pendiente_positiva": cond_pendiente,
        "distancia_suficiente": cond_distancia,
    }

    if cond_sobre_mm50 and cond_sobre_mm200 and cond_mm50_sobre_mm200:
        tendencia = "ALCISTA"
    elif not cond_sobre_mm200:
        tendencia = "BAJISTA"
    else:
        tendencia = "LATERAL"

    cumple = (tendencia == "ALCISTA" and cond_pendiente and cond_distancia)

    return {
        "tendencia":            tendencia,
        "mm50":                 mm50,
        "mm200":                mm200,
        "distancia_mm50_pct":   distancia_mm50_pct,
        "pendiente_mm50":       pendiente_mm50,
        "cumple_criterios":     cumple,
        "condiciones":          condiciones,
    }


def detectar_consolidacion(precios, lookback_max=26):
    """
    Detecta si el precio lleva lookback_max semanas en un rango estrecho.

    Returns dict:
        en_consolidacion:        bool
        semanas_consolidacion:   int
        rango_pct:               float  (amplitud del rango)
        posicion_en_rango:       float  (0=mínimo, 100=máximo)
    """
    if hasattr(precios, 'tolist'): precios = precios.tolist()
    n = min(lookback_max, len(precios))
    if n < 4:
        return {"en_consolidacion": False, "semanas_consolidacion": 0,
                "rango_pct": 0.0, "posicion_en_rango": 50.0}

    ventana = precios[-n:]
    máx = max(ventana)
    mín = min(ventana)
    precio = precios[-1]

    if mín <= 0:
        return {"en_consolidacion": False, "semanas_consolidacion": 0,
                "rango_pct": 0.0, "posicion_en_rango": 50.0}

    rango_pct = (máx - mín) / mín * 100
    posicion  = (precio - mín) / (máx - mín) * 100 if máx > mín else 50.0

    # Consolidación: rango contenido Y precio en parte alta del rango
    en_consolidacion = rango_pct <= 22.0 and posicion >= 60.0

    return {
        "en_consolidacion":     en_consolidacion,
        "semanas_consolidacion": n,
        "rango_pct":            round(rango_pct, 2),
        "posicion_en_rango":    round(posicion, 1),
    }


def detectar_breakout(precios, volumenes=None, lookback=26):
    """
    Detecta rotura de máximos recientes con confirmación de volumen.

    Returns dict:
        hay_breakout:            bool
        distancia_breakout_pct:  float  (% sobre el máximo previo)
        ratio_volumen:           float  (volumen actual / media)
        volumen_confirma:        bool
    """
    # Normalizar a listas para evitar problemas con numpy arrays
    if hasattr(precios, 'tolist'):
        precios = precios.tolist()
    if volumenes is not None and hasattr(volumenes, 'tolist'):
        volumenes = volumenes.tolist()

    n = len(precios)
    if n < lookback + 1:
        return {"hay_breakout": False, "distancia_breakout_pct": 0.0,
                "ratio_volumen": 1.0, "volumen_confirma": False}

    precio_actual = precios[-1]
    # Máximo de las semanas previas (excluir la actual)
    max_previo = max(precios[-(lookback+1):-1])

    distancia_pct = (precio_actual - max_previo) / max_previo * 100
    hay_breakout  = distancia_pct >= -1.5   # dentro del 1.5% del máximo o por encima

    # Volumen
    ratio_volumen  = 1.0
    volumen_confirma = False
    if volumenes is not None and len(volumenes) >= lookback:
        vol_actual = volumenes[-1]
        media_vol  = sum(volumenes[-lookback:-1]) / (lookback - 1)
        if media_vol > 0:
            ratio_volumen    = float(vol_actual) / media_vol
            volumen_confirma = ratio_volumen >= 1.2

    return {
        "hay_breakout":           hay_breakout,
        "distancia_breakout_pct": round(distancia_pct, 2),
        "ratio_volumen":          round(ratio_volumen, 2),
        "volumen_confirma":       volumen_confirma,
    }


def calcular_volatilidad(precios, periodo=52):
    """
    Volatilidad anualizada como desviación estándar de retornos semanales.
    """
    n = min(periodo, len(precios))
    if n < 4:
        return None
    ventana = precios[-n:]
    retornos = [(ventana[i] - ventana[i-1]) / ventana[i-1]
                for i in range(1, len(ventana)) if ventana[i-1] > 0]
    if len(retornos) < 3:
        return None
    std = (sum((r - sum(retornos)/len(retornos))**2
               for r in retornos) / len(retornos)) ** 0.5
    return std * (52 ** 0.5) * 100   # anualizado en %


def calcular_stop_inicial(entrada, precios, df=None):
    """
    Stop inicial posicional: bajo el mínimo reciente (8 semanas) con margen.
    Rango válido: 6–15% bajo la entrada.
    """
    n = min(8, len(precios))
    min_reciente = min(precios[-n:]) if n >= 2 else entrada * 0.90

    stop = min_reciente * 0.985   # 1.5% por debajo del mínimo

    # Validar rango 6-15%
    dist_pct = (entrada - stop) / entrada * 100
    if dist_pct < 6.0:
        stop = entrada * (1 - 6.0 / 100)
    elif dist_pct > 15.0:
        stop = entrada * (1 - 15.0 / 100)

    return round(stop, 2)


def validar_riesgo(entrada, stop):
    """
    Valida que el riesgo esté entre RIESGO_MIN_PCT y RIESGO_MAX_PCT.
    """
    if not entrada or not stop or entrada <= 0:
        return {"riesgo_valido": False, "riesgo_pct": 0.0,
                "motivo": "Entrada o stop inválido"}

    riesgo_pct = (entrada - stop) / entrada * 100

    if riesgo_pct < 6.0:
        return {"riesgo_valido": False, "riesgo_pct": riesgo_pct,
                "motivo": f"Stop demasiado ajustado ({riesgo_pct:.1f}% < 6%)"}
    if riesgo_pct > 15.0:
        return {"riesgo_valido": False, "riesgo_pct": riesgo_pct,
                "motivo": f"Stop demasiado amplio ({riesgo_pct:.1f}% > 15%)"}

    return {"riesgo_valido": True, "riesgo_pct": riesgo_pct, "motivo": "OK"}
