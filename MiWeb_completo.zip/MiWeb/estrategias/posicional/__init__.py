from .logica_posicional import Posicional
from .scanner_posicional import ScannerPosicional
