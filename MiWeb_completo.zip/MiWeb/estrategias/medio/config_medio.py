# ==========================================================
# CONFIGURACIÓN — SISTEMA MEDIO PLAZO
# Timeframe: 4-12 semanas (semanal)
# ==========================================================

# Medias móviles
MM_TENDENCIA_CORTA  = 10
MM_TENDENCIA_MEDIA  = 20
MM_TENDENCIA_LARGA  = 40

# ATR
ATR_PERIODO = 14

# Pullback
PULLBACK_MIN_PCT    = 5.0
PULLBACK_MAX_PCT    = 20.0
LOOKBACK_MAXIMO     = 26

# Stop
STOP_ATR_MULTIPLICADOR   = 2.0
STOP_ESTRUCTURA_LOOKBACK = 13

# Riesgo
RIESGO_MIN_PCT = 2.0
RIESGO_MAX_PCT = 8.0

# Backtest
CAPITAL_INICIAL       = 50_000
RIESGO_POR_TRADE_PCT  = 1.0
MIN_SEMANAS_HISTORICO = 52

# Trailing
R_PARA_PROTEGER  = 2.0
R_PARA_TRAILING  = 4.0

# Universo (importado de core si está disponible)
try:
    from core.universos import IBEX35, CONTINUO
    TICKER_EMPRESA = {}
except ImportError:
    IBEX35   = []
    CONTINUO = []
    TICKER_EMPRESA   = {}
