# web/routes/medio_routes.py
# ══════════════════════════════════════════════════════════════
# RUTAS MEDIO PLAZO
# Solo lógica HTTP — sin indicadores, sin yfinance, sin sizing.
# ══════════════════════════════════════════════════════════════

from flask import Blueprint, request, redirect, url_for, render_template, current_app
from core.universos import get_nombre, normalizar_ticker, IBEX35, CONTINUO
from core.contexto_mercado import evaluar_contexto_ibex, factor_riesgo_mercado
from core.riesgo import resumen_operacion
from estrategias.medio import MedioPlazo, ScannerMedio

medio_bp = Blueprint("medio", __name__, url_prefix="/medio")

_medio   = MedioPlazo()
_scanner = ScannerMedio()


def _get_cache():
    return current_app.config.get("CACHE_INSTANCE")


def _params_capital(form):
    try:
        capital_total = float(form.get("capital_total", 10000))
        riesgo_pct    = float(form.get("riesgo_pct", 1.0))
    except (ValueError, TypeError):
        capital_total = 10000.0
        riesgo_pct    = 1.0
    return capital_total, riesgo_pct


# ─────────────────────────────────────────────────────────────
# PANEL PRINCIPAL
# ─────────────────────────────────────────────────────────────

@medio_bp.route("/", methods=["GET"])
def panel():
    contexto = evaluar_contexto_ibex(_get_cache())
    return render_template("medio.html", contexto_mercado=contexto)


# ─────────────────────────────────────────────────────────────
# ANÁLISIS INDIVIDUAL
# ─────────────────────────────────────────────────────────────

@medio_bp.route("/analizar", methods=["POST"])
def analizar():
    ticker = normalizar_ticker(request.form.get("ticker", ""))
    if not ticker:
        return redirect(url_for("medio.panel"))

    cache           = _get_cache()
    capital, riesgo = _params_capital(request.form)

    señal    = _medio.evaluar(ticker, cache)
    contexto = evaluar_contexto_ibex(cache)
    factor   = factor_riesgo_mercado(cache)

    operacion = None
    if señal.get("valido"):
        operacion = resumen_operacion(
            entrada        = señal["entrada"],
            stop           = señal["stop"],
            objetivo       = señal["objetivo"],
            capital_total  = capital,
            riesgo_pct     = riesgo,
            factor_mercado = factor,
        )

    return render_template(
        "medio.html",
        ticker           = ticker,
        nombre_valor     = get_nombre(ticker),
        señal            = señal,
        operacion        = operacion,
        capital_total    = capital,
        riesgo_pct       = riesgo,
        contexto_mercado = contexto,
    )


# ─────────────────────────────────────────────────────────────
# ESCÁNER
# ─────────────────────────────────────────────────────────────

@medio_bp.route("/scanner", methods=["GET"])
def scanner():
    cache    = _get_cache()
    universo = request.args.get("universo", "todo")
    tickers  = {"ibex": IBEX35, "continuo": CONTINUO}.get(universo)

    resultados = _scanner.escanear_todo(cache=cache, top_n=20)
    if tickers:
        resultados["señales"] = [
            s for s in resultados["señales"] if s["ticker"] in tickers
        ]

    return render_template(
        "medio_scanner.html",
        **resultados,
        universo=universo,
    )
