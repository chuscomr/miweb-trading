# core/data_provider.py
# ══════════════════════════════════════════════════════════════
# PROVEEDOR DE DATOS — PUNTO ÚNICO DE DESCARGA
#
# REGLA: Ningún módulo llama a yf.download() o yf.Ticker() directamente.
# Todos usan get_df() de aquí.
#
# Funciona en dos modos:
#   1. Con cache Flask  → evita re-descargas durante la sesión web
#   2. Sin cache (None) → descarga directa (backtest, scripts CLI)
#
# Formato de salida: DataFrame OHLCV con columnas simples (no MultiIndex)
#   Index: DatetimeIndex
#   Columnas: Open, High, Low, Close, Volume
# ══════════════════════════════════════════════════════════════

import yfinance as yf
import pandas as pd
import numpy as np
import os
import logging
from typing import Optional
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# CONSTANTES
# ─────────────────────────────────────────────────────────────

PERIODO_DEFAULT   = "1y"
MIN_VELAS         = 50          # mínimo de filas para considerar datos válidos
CACHE_TIMEOUT_SEG = 600         # 10 min — mismo que la cache Flask actual
PARQUET_DIR       = os.path.join(os.path.dirname(__file__), "..", "data_cache")

# ─────────────────────────────────────────────────────────────
# LIMPIEZA DE DATAFRAME
# ─────────────────────────────────────────────────────────────

def _limpiar_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normaliza el DataFrame que devuelve yfinance:
    - Aplana MultiIndex de columnas si existe
    - Renombra a nombres canónicos
    - Elimina filas con NaN en Close
    - Elimina outliers extremos (variación > 30% diaria)
    - Ordena por fecha ascendente
    """
    if df is None or df.empty:
        return pd.DataFrame()

    # Aplanar MultiIndex (yfinance a veces lo devuelve)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    # Asegurar columnas canónicas
    df.columns = [c.strip().title() for c in df.columns]

    # Eliminar NaN en Close
    df = df.dropna(subset=["Close"])

    # Filtrar outliers diarios
    variacion = df["Close"].pct_change().abs()
    df = df[variacion.isna() | (variacion < 0.30)]

    # Ordenar
    df = df.sort_index()

    return df


# ─────────────────────────────────────────────────────────────
# DESCARGA PRINCIPAL
# ─────────────────────────────────────────────────────────────

def _descargar_yfinance(ticker: str, periodo: str) -> pd.DataFrame:
    """Descarga raw desde yfinance y limpia. Devuelve DataFrame o vacío."""
    try:
        logger.info(f"📥 Descargando {ticker} ({periodo})...")
        raw = yf.Ticker(ticker).history(period=periodo)
        if raw is None or raw.empty:
            logger.warning(f"⚠️ Sin datos para {ticker}")
            return pd.DataFrame()
        return _limpiar_df(raw)
    except Exception as e:
        logger.error(f"❌ Error descargando {ticker}: {e}")
        return pd.DataFrame()


# ─────────────────────────────────────────────────────────────
# API PÚBLICA
# ─────────────────────────────────────────────────────────────

def get_df(
    ticker: str,
    periodo: str = PERIODO_DEFAULT,
    cache=None,
    min_velas: int = MIN_VELAS,
) -> Optional[pd.DataFrame]:
    """
    Obtiene un DataFrame OHLCV limpio para el ticker.

    Args:
        ticker:     Ticker de Yahoo Finance (ej: "BBVA.MC", "^IBEX")
        periodo:    Periodo yfinance: "1d", "5d", "1mo", "3mo", "6mo",
                    "1y", "2y", "5y", "10y", "ytd", "max"
        cache:      Objeto Cache de Flask (opcional). Si es None, descarga directa.
        min_velas:  Mínimo de filas requeridas. Devuelve None si no se alcanza.

    Returns:
        pd.DataFrame con columnas [Open, High, Low, Close, Volume]
        o None si no hay datos suficientes.
    """
    if cache is not None:
        cache_key = f"df_{ticker}_{periodo}"
        df = cache.get(cache_key)
        if df is not None:
            logger.debug(f"✅ Cache hit: {cache_key}")
            return df if len(df) >= min_velas else None

    df = _descargar_yfinance(ticker, periodo)

    if df.empty or len(df) < min_velas:
        logger.warning(f"⚠️ {ticker}: datos insuficientes ({len(df)} velas, mínimo {min_velas})")
        return None

    if cache is not None:
        cache.set(cache_key, df, timeout=CACHE_TIMEOUT_SEG)

    return df


def get_df_ibex(cache=None, periodo: str = "1y") -> Optional[pd.DataFrame]:
    """Atajo para obtener el IBEX 35 (^IBEX). Usado por contexto_mercado."""
    return get_df("^IBEX", periodo=periodo, cache=cache, min_velas=210)


# ─────────────────────────────────────────────────────────────
# HELPERS DE EXTRACCIÓN (compatibilidad con código legado)
# ─────────────────────────────────────────────────────────────

def df_a_listas(df: pd.DataFrame) -> tuple:
    """
    Convierte un DataFrame a listas (precios, volumenes, fechas, precio_actual).
    Mantiene compatibilidad con el código antiguo que usa listas.

    Returns:
        (precios: list, volumenes: list, fechas: list, precio_actual: float)
        o (None, None, None, None) si el df es inválido.
    """
    if df is None or df.empty:
        return None, None, None, None

    try:
        precios    = df["Close"].tolist()
        volumenes  = df["Volume"].tolist()
        fechas     = df.index.to_pydatetime().tolist()
        precio_actual = precios[-1] if precios else None
        return precios, volumenes, fechas, precio_actual
    except Exception as e:
        logger.error(f"❌ df_a_listas: {e}")
        return None, None, None, None


def get_precios(ticker: str, periodo: str = PERIODO_DEFAULT, cache=None) -> tuple:
    """
    Atajo completo: descarga y devuelve listas.
    Reemplaza la función obtener_precios() de logica.py.

    Returns:
        (precios, volumenes, fechas, precio_actual) o (None, None, None, None)
    """
    df = get_df(ticker, periodo=periodo, cache=cache)
    return df_a_listas(df)


# ─────────────────────────────────────────────────────────────
# CACHE LOCAL EN DISCO (parquet)  — para backtesting offline
# ─────────────────────────────────────────────────────────────

def guardar_parquet(ticker: str, df: pd.DataFrame) -> bool:
    """Guarda el DataFrame en data_cache/{ticker}.parquet."""
    try:
        os.makedirs(PARQUET_DIR, exist_ok=True)
        path = os.path.join(PARQUET_DIR, f"{ticker.replace('.', '_')}.parquet")
        df.to_parquet(path)
        logger.info(f"💾 Guardado: {path}")
        return True
    except Exception as e:
        logger.error(f"❌ guardar_parquet {ticker}: {e}")
        return False


def cargar_parquet(ticker: str) -> Optional[pd.DataFrame]:
    """Carga datos desde data_cache/{ticker}.parquet si existe."""
    try:
        path = os.path.join(PARQUET_DIR, f"{ticker.replace('.', '_')}.parquet")
        if not os.path.exists(path):
            return None
        df = pd.read_parquet(path)
        return _limpiar_df(df)
    except Exception as e:
        logger.error(f"❌ cargar_parquet {ticker}: {e}")
        return None


def get_df_con_fallback(
    ticker: str,
    periodo: str = PERIODO_DEFAULT,
    cache=None,
) -> Optional[pd.DataFrame]:
    """
    Intenta en orden:
      1. Cache Flask (si disponible)
      2. Parquet local (data_cache/)
      3. Descarga yfinance

    Ideal para backtesting donde se quiere evitar llamadas repetidas a la API.
    """
    # 1. Cache Flask
    if cache is not None:
        df = get_df(ticker, periodo, cache)
        if df is not None:
            return df

    # 2. Parquet local
    df = cargar_parquet(ticker)
    if df is not None and not df.empty:
        logger.info(f"📂 Usando parquet local para {ticker}")
        return df

    # 3. Descarga fresca
    df = get_df(ticker, periodo, cache=None)
    if df is not None:
        guardar_parquet(ticker, df)  # guarda para próximas veces
    return df
