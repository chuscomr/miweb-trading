# estrategias/medio/backtest_medio.py
# Portado de backtest_medio.py del sistema antiguo

import numpy as np
from estrategias.medio.config_medio import MIN_SEMANAS_HISTORICO
from estrategias.medio.logica_medio import detectar_tendencia_semanal, detectar_pullback, calcular_stop_inicial


def _evaluar_entrada(df_hasta_ahora):
    """Evalúa si hay señal de compra en la barra actual."""
    precios  = df_hasta_ahora["Close"].tolist()
    tendencia = detectar_tendencia_semanal(precios)
    pullback  = detectar_pullback(precios)

    if tendencia.get("tendencia") != "ALCISTA" or not pullback.get("es_pullback"):
        return {"decision": "NO OPERAR"}

    entrada = precios[-1]
    stop    = calcular_stop_inicial(entrada, precios, df=df_hasta_ahora)
    if stop is None or stop >= entrada:
        return {"decision": "NO OPERAR"}

    riesgo_pct = (entrada - stop) / entrada * 100
    return {
        "decision":   "COMPRA",
        "entrada":    entrada,
        "stop":       stop,
        "riesgo_pct": round(riesgo_pct, 2),
    }


def _calcular_metricas(trades, equity_curve):
    if not trades:
        return {k: 0 for k in [
            "total_trades","expectancy_R","winrate","mejor_trade","peor_trade",
            "avg_winner","avg_loser","profit_factor","max_drawdown_R","equity_final_R"
        ]}
    Rs      = [t["R"] for t in trades]
    winners = [r for r in Rs if r > 0]
    losers  = [r for r in Rs if r <= 0]
    pf      = sum(winners) / abs(sum(losers)) if losers else 0
    eq      = np.array(equity_curve)
    dd      = float(min(eq - np.maximum.accumulate(eq))) if len(eq) > 1 else 0
    return {
        "total_trades":   len(trades),
        "expectancy_R":   round(sum(Rs)/len(Rs), 2),
        "winrate":        round(len(winners)/len(Rs)*100, 1),
        "mejor_trade":    round(max(Rs), 2),
        "peor_trade":     round(min(Rs), 2),
        "avg_winner":     round(sum(winners)/len(winners), 2) if winners else 0,
        "avg_loser":      round(sum(losers)/len(losers), 2)   if losers  else 0,
        "profit_factor":  round(pf, 2),
        "max_drawdown_R": round(dd, 2),
        "equity_final_R": round(equity_curve[-1], 2) if equity_curve else 0,
    }


def ejecutar_backtest_medio_plazo(df_semanal, ticker=None, verbose=False):
    """Motor de backtest semanal para medio plazo."""
    if df_semanal is None or df_semanal.empty or len(df_semanal) < MIN_SEMANAS_HISTORICO:
        return {"trades": [], "equity": [], "metricas": _calcular_metricas([], [])}

    trades       = []
    equity_curve = [0.0]
    posicion     = None   # dict con entrada, stop, riesgo_unit, fecha_entrada

    for i in range(MIN_SEMANAS_HISTORICO, len(df_semanal)):
        df_v   = df_semanal.iloc[:i+1]
        precio = df_v["Close"].iloc[-1]
        high   = df_v["High"].iloc[-1]
        low    = df_v["Low"].iloc[-1]
        fecha  = df_v.index[-1]

        # Gestión posición abierta
        if posicion:
            riesgo = posicion["riesgo_unit"]
            # Break-even en +1R
            if not posicion.get("be") and high >= posicion["entrada"] + riesgo:
                posicion["stop"] = posicion["entrada"]
                posicion["be"]   = True
            # TARGET +3R
            if high >= posicion["entrada"] + 3 * riesgo:
                R = 3.0
                trades.append({"fecha_entrada": posicion["fecha"], "fecha_salida": fecha,
                                "entrada": posicion["entrada"], "stop_inicial": posicion["stop_ini"],
                                "salida": precio, "R": R, "motivo": "TARGET", "semanas": i - posicion["bar"]})
                equity_curve.append(equity_curve[-1] + R)
                posicion = None
                continue
            # STOP
            if low <= posicion["stop"]:
                R_unit = posicion["riesgo_unit"]
                R = (posicion["stop"] - posicion["entrada"]) / R_unit if R_unit else -1.0
                trades.append({"fecha_entrada": posicion["fecha"], "fecha_salida": fecha,
                                "entrada": posicion["entrada"], "stop_inicial": posicion["stop_ini"],
                                "salida": posicion["stop"], "R": round(R, 2), "motivo": "STOP",
                                "semanas": i - posicion["bar"]})
                equity_curve.append(equity_curve[-1] + R)
                posicion = None

        # Buscar entrada
        if not posicion:
            señal = _evaluar_entrada(df_v)
            if señal["decision"] == "COMPRA":
                posicion = {
                    "entrada":    señal["entrada"],
                    "stop":       señal["stop"],
                    "stop_ini":   señal["stop"],
                    "riesgo_unit": señal["entrada"] - señal["stop"],
                    "fecha":      fecha,
                    "bar":        i,
                    "be":         False,
                }

    # Cerrar posición al final si queda abierta
    if posicion:
        R_unit = posicion["riesgo_unit"]
        precio_f = df_semanal["Close"].iloc[-1]
        R = (precio_f - posicion["entrada"]) / R_unit if R_unit else 0
        trades.append({"fecha_entrada": posicion["fecha"], "fecha_salida": df_semanal.index[-1],
                       "entrada": posicion["entrada"], "stop_inicial": posicion["stop_ini"],
                       "salida": precio_f, "R": round(R, 2), "motivo": "FIN_BACKTEST",
                       "semanas": len(df_semanal) - posicion["bar"]})
        equity_curve.append(equity_curve[-1] + R)

    return {"trades": trades, "equity": equity_curve, "metricas": _calcular_metricas(trades, equity_curve)}
