# web/routes/indicadores_routes.py
# ══════════════════════════════════════════════════════════════
# RUTAS INDICADORES — Laboratorio técnico visual
# ══════════════════════════════════════════════════════════════

from flask import Blueprint, render_template, request, jsonify, current_app
from core.universos import normalizar_ticker, IBEX35, CONTINUO
from core.data_provider import get_df
from core.indicadores import (
    calcular_rsi, calcular_macd, calcular_atr,
    calcular_bollinger, calcular_adx,
)

indicadores_bp = Blueprint(
    "indicadores", __name__,
    url_prefix="/indicadores",
    static_folder="../../static",   # apunta a MiWeb/static
    static_url_path="/indicadores/static",
)


def _get_cache():
    return current_app.config.get("CACHE_INSTANCE")


# ─────────────────────────────────────────────────────────────
# PANEL PRINCIPAL
# ─────────────────────────────────────────────────────────────

@indicadores_bp.route("/", methods=["GET"])
def panel():
    return render_template(
        "indicadores.html",
        tickers_ibex     = IBEX35,
        tickers_continuo = CONTINUO,
    )


# ─────────────────────────────────────────────────────────────
# API JSON — datos para el gráfico Plotly
# GET /indicadores/api?ticker=SAN.MC&tf=1d&ind=rsi,macd,bb
# ─────────────────────────────────────────────────────────────

@indicadores_bp.route("/api", methods=["GET"])
def api_datos():
    ticker      = normalizar_ticker(request.args.get("ticker", ""))
    tf          = request.args.get("tf", "1d")
    ind_param   = request.args.get("ind", "")
    indicadores = [i.strip().lower() for i in ind_param.split(",") if i.strip()]

    if not ticker:
        return jsonify({"error": "Ticker requerido"}), 400

    # Periodo según timeframe
    periodos = {"1d": "1y", "1wk": "5y", "1mo": "10y"}
    periodo  = periodos.get(tf, "1y")

    cache = _get_cache()
    df    = get_df(ticker, periodo=periodo, cache=cache, intervalo=tf)

    if df is None or df.empty:
        return jsonify({"error": f"Sin datos para {ticker}"}), 404

    # Construir respuesta base
    fechas  = [str(d.date()) for d in df.index]
    closes  = df["Close"].round(4).tolist()
    opens   = df["Open"].round(4).tolist()   if "Open"   in df.columns else closes
    highs   = df["High"].round(4).tolist()   if "High"   in df.columns else closes
    lows    = df["Low"].round(4).tolist()    if "Low"    in df.columns else closes
    volumes = df["Volume"].tolist()          if "Volume" in df.columns else []

    resultado = {
        "ticker":  ticker,
        "tf":      tf,
        "fechas":  fechas,
        "close":   closes,
        "open":    opens,
        "high":    highs,
        "low":     lows,
        "volume":  volumes,
    }

    # Indicadores opcionales
    try:
        if "rsi" in indicadores:
            rsi = calcular_rsi(df["Close"], 14)
            resultado["rsi"] = [round(v, 2) if v == v else None for v in rsi.tolist()]

        if "macd" in indicadores:
            macd = calcular_macd(df["Close"])
            resultado["macd"]       = [round(v, 4) if v == v else None for v in macd["macd"].tolist()]
            resultado["macd_señal"] = [round(v, 4) if v == v else None for v in macd["señal"].tolist()]
            resultado["macd_hist"]  = [round(v, 4) if v == v else None for v in macd["histograma"].tolist()]

        if "bb" in indicadores or "bollinger" in indicadores:
            bb = calcular_bollinger(df["Close"])
            resultado["bb_upper"] = [round(v, 4) if v == v else None for v in bb["upper"].tolist()]
            resultado["bb_mid"]   = [round(v, 4) if v == v else None for v in bb["mid"].tolist()]
            resultado["bb_lower"] = [round(v, 4) if v == v else None for v in bb["lower"].tolist()]

        if "atr" in indicadores:
            atr = calcular_atr(df, 14)
            resultado["atr"] = [round(v, 4) if v == v else None for v in atr.tolist()]

        if "adx" in indicadores:
            adx = calcular_adx(df, 14)
            resultado["adx"] = [round(v, 2) if v == v else None for v in adx.tolist()]

        if "mm20" in indicadores or "mm" in indicadores:
            mm20 = df["Close"].rolling(20).mean()
            resultado["mm20"] = [round(v, 4) if v == v else None for v in mm20.tolist()]

        if "mm50" in indicadores or "mm" in indicadores:
            mm50 = df["Close"].rolling(50).mean()
            resultado["mm50"] = [round(v, 4) if v == v else None for v in mm50.tolist()]

        if "mm200" in indicadores or "mm" in indicadores:
            mm200 = df["Close"].rolling(200).mean()
            resultado["mm200"] = [round(v, 4) if v == v else None for v in mm200.tolist()]

    except Exception as e:
        resultado["warning"] = f"Error calculando indicadores: {str(e)}"

    return jsonify(resultado)
